// import React from 'react';
// import styles from './NavBar.module.css';

// const NavBar = () => {
//   return (
//     <nav className={styles.navbar}>
//       <div className={styles.navContent}>
//         <div className={styles.navLinks}>
//           <div className={styles.logo}>GLOWPAINTRUN</div>
//           <div className={styles.linkContainer}>
//             <a href="#home" className={styles.navLink}>Home</a>
//             <a href="#event" className={styles.navLink}>Event</a>
//             <a href="#kit-collection" className={styles.navLink}>Kit Collection</a>
//             <a href="#e-cert" className={styles.navLink}>E-Cert</a>
//           </div>
//         </div>
//         <button className={styles.signInButton}>Sign In</button>
//       </div>
//     </nav>
//   );
// };

// export default NavBar;