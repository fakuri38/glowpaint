// import "./OverlayModal.module.css";
// import { RegistrationForm } from "../RegistrationForm/RegistrationForm";

// export function OverlayModal({ isOpen, onClose, children }) {
//   return (
//     <>
//       {isOpen && (
//         <div className="overlay">
//           <div className="overlay__background">
//             <div className="overlay__container">
//               <div className="overlay__controls">
//                 <button
//                   className="overlay__close"
//                   type="button"
//                   onClick={onClose}
//                 />
//               </div>
//               {/* {children} */}
//               {/* <h1>Hello</h1> */}
//               <RegistrationForm />
//             </div>
//           </div>
//         </div>
//       )}
//     </>
//   );
// }
